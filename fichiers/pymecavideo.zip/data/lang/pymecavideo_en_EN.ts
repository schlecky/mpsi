<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>StartQT4</name>
</context>
<context>
    <name>pymecavideo</name>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="31"/>
        <source>PyMecaVideo, analyse mécanique des vidéos</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="71"/>
        <source>Acquisition des données</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="174"/>
        <source>Pas de vidéos chargées</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="214"/>
        <source>Image n°</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="265"/>
        <source>Acquisition video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="300"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="367"/>
        <source>Acquisition</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="382"/>
        <source>Démarrer</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="416"/>
        <source>efface la série précédente</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="453"/>
        <source>rétablit le point suivant</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="533"/>
        <source>Tout réinitialiser</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="549"/>
        <source>Définir l&apos;échelle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="562"/>
        <source>px/m</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="584"/>
        <source>indéf.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="619"/>
        <source>Points à 
 étudier:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="637"/>
        <source>suivi
automatique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="648"/>
        <source>Changer d&apos;origine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="658"/>
        <source>Abscisses 
vers la gauche</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="666"/>
        <source>Ordonnées 
vers le bas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="676"/>
        <source>Trajectoires</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="780"/>
        <source>Montrer 
les vecteurs
vitesses</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="789"/>
        <source>près de
la souris</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="800"/>
        <source>partout</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="807"/>
        <source>Échelle de vitesses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="830"/>
        <source>px pour 1 m/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="860"/>
        <source>Voir un graphique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="874"/>
        <source>Choisir ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="891"/>
        <source>Voir la vidéo</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="920"/>
        <source>Définir un autre référentiel : </source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="926"/>
        <source>Coordonnées</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="932"/>
        <source>Tableau des dates et des coordonnées</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="938"/>
        <source>Copier les mesures dans le presse papier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="946"/>
        <source>Exporter vers ....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="951"/>
        <source>Oo.o Calc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="956"/>
        <source>Qtiplot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="961"/>
        <source>SciDAVis</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="969"/>
        <source>changer d&apos;échelle ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1009"/>
        <source>&amp;Fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1013"/>
        <source>E&amp;xporter vers ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1030"/>
        <source>&amp;Aide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1039"/>
        <source>&amp;Edition</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="1056"/>
        <source>&amp;Ouvrir une vidéo (Ctrl-O)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1064"/>
        <source>avanceimage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1069"/>
        <source>reculeimage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1074"/>
        <source>Quitter (Ctrl-Q)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="1082"/>
        <source>Enregistrer les données (Ctrl-S)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="1090"/>
        <source>À &amp;propos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1095"/>
        <source>Aide (F1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1103"/>
        <source>Exemples ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="1108"/>
        <source>Ouvrir un projet &amp;mecavidéo</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="1113"/>
        <source>&amp;Préférences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1118"/>
        <source>&amp;Copier dans le presse-papier (Ctrl-C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="1126"/>
        <source>Défaire (Ctrl-Z)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1134"/>
        <source>Refaire (Ctrl-Y)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1142"/>
        <source>OpenOffice.org &amp;Calc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1147"/>
        <source>Qti&amp;plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1152"/>
        <source>Sci&amp;davis</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>self.app</name>
    <message>
        <location filename="cadreur.py" line="48"/>
        <source>Presser la touche ESC pour sortir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="echelle.py" line="142"/>
        <source>Choisir le nombre de points puis &#xc2;&#xab;&#xc2;&#xa0;D&#xc3;&#xa9;marrer l&apos;acquisition&#xc2;&#xa0;&#xc2;&#xbb; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="echelle.py" line="147"/>
        <source>Vous pouvez continuer votre acquisition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="preferences.py" line="48"/>
        <source>Proximite de la souris %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="preferences.py" line="49"/>
        <source>; derniere video %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="preferences.py" line="50"/>
        <source>; videoDir %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
