<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="fr_FR">
<context encoding="UTF-8">
    <name>StartQT4</name>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="325"/>
        <source>indéf</source>
        <translation type="obsolete">indéf</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="398"/>
        <source>indéf.</source>
        <comment>utf8</comment>
        <translation type="obsolete">indéf.</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="994"/>
        <source>temps en seconde, positions en mètre</source>
        <translation type="obsolete">temps en seconde, positions en mètre</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1056"/>
        <source>point N°</source>
        <translation type="obsolete">point N°</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1230"/>
        <source>Evolution de l&apos;ordonnée du point %1</source>
        <translation type="obsolete">Evolution de l&apos;ordonnée du point %1</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1324"/>
        <source>Vous avez atteint la fin de la vidéo</source>
        <translation type="obsolete">Vous avez atteint la fin de la vidéo</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1465"/>
        <source>Quelle est la longueur en mètre de votre étalon sur l&apos;image ?</source>
        <translation type="obsolete">Quelle est la longueur en mètre de votre étalon sur l&apos;image ?</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1483"/>
        <source> Merci d&apos;indiquer une échelle valable</source>
        <translation type="obsolete"> Merci d&apos;indiquer une échelle valable</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1542"/>
        <source>Les données seront perdues</source>
        <translation type="obsolete">Les données seront perdues</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1542"/>
        <source>Votre travail n&apos;a pas été sauvegardé
Voulez-vous les sauvegarder ?</source>
        <translation type="obsolete">Votre travail n&apos;a pas été sauvegardé
Voulez-vous les sauvegarder ?</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1563"/>
        <source>Vous avez atteint le début de la vidéo</source>
        <translation type="obsolete">Vous avez atteint le début de la vidéo</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1597"/>
        <source>Ouvrir une vidéo</source>
        <translation type="obsolete">Ouvrir une vidéo</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1576"/>
        <source>fichiers vidéos ( *.avi *.mp4 *.ogv *.mpg *.mpeg *.ogg *.mov *.wmv)</source>
        <translation type="obsolete">fichiers vidéos ( *.avi *.mp4 *.ogv *.mpg *.mpeg *.ogg *.mov *.wmv)</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1585"/>
        <source>fichiers vidéos ( *.avi *.mp4 *.ogv *.mpg *.mpeg *.ogg *.wmv *.mov)</source>
        <translation type="obsolete">fichiers vidéos ( *.avi *.mp4 *.ogv *.mpg *.mpeg *.ogg *.wmv *.mov)</translation>
    </message>
    <message>
        <location filename="pymecavideo.py" line="1594"/>
        <source>Nom de fichier non conforme</source>
        <translation type="obsolete">Nom de fichier non conforme</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1594"/>
        <source>Le nom de votre fichier contient des caractères accentués ou des espaces.
Merci de bien vouloir le renommer avant de continuer</source>
        <comment>utf8</comment>
        <translation type="obsolete">Le nom de votre fichier contient des caractères accentués ou des espaces.
Merci de bien vouloir le renommer avant de continuer</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1623"/>
        <source>Veuillez choisir une image et définir l&apos;échelle</source>
        <translation type="obsolete">Veuillez choisir une image et définir l&apos;échelle</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.py" line="1657"/>
        <source>Désolé pas de fichier d&apos;aide pour le langage %1.</source>
        <translation type="obsolete">Désolé pas de fichier d&apos;aide pour le langage %1.</translation>
    </message>
</context>
<context>
    <name>pymecavideo</name>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="31"/>
        <source>PyMecaVideo, analyse mécanique des vidéos</source>
        <translation>PyMecaVideo, analyse mécanique des vidéos</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="71"/>
        <source>Acquisition des données</source>
        <translation>Acquisition des données</translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="300"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="pymecavideo.ui" line="172"/>
        <source>Pointage</source>
        <translation type="obsolete">Pointage</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="382"/>
        <source>Démarrer</source>
        <translation>Démarrer</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="416"/>
        <source>efface la série précédente</source>
        <translation>efface la série précédente</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="453"/>
        <source>rétablit le point suivant</source>
        <translation>rétablit le point suivant</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="533"/>
        <source>Tout réinitialiser</source>
        <translation>Tout réinitialiser</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="549"/>
        <source>Définir l&apos;échelle</source>
        <translation>Définir l&apos;échelle</translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="562"/>
        <source>px/m</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="584"/>
        <source>indéf.</source>
        <translation>indéf.</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="619"/>
        <source>Points à 
 étudier:</source>
        <translation>Points à 
 étudier:</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="666"/>
        <source>Ordonnées 
vers le bas</source>
        <translation>Ordonnées 
vers le bas</translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="658"/>
        <source>Abscisses 
vers la gauche</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.ui" line="526"/>
        <source>Lancer le logiciel
 d&apos;acquisition Vidéo</source>
        <translation type="obsolete">Lancer le logiciel
 d&apos;acquisition Vidéo</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="214"/>
        <source>Image n°</source>
        <translation>Image n°</translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="676"/>
        <source>Trajectoires</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="891"/>
        <source>Voir la vidéo</source>
        <translation>Voir la vidéo</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo.ui" line="725"/>
        <source>Depuis ce référentiel</source>
        <translation type="obsolete">Depuis ce référentiel</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="807"/>
        <source>Échelle de vitesses</source>
        <translation>Échelle de vitesses</translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="830"/>
        <source>px pour 1 m/s</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="860"/>
        <source>Voir un graphique</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="874"/>
        <source>Choisir ...</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="926"/>
        <source>Coordonnées</source>
        <translation>Coordonnées</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="932"/>
        <source>Tableau des dates et des coordonnées</source>
        <translation>Tableau des dates et des coordonnées</translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="938"/>
        <source>Copier les mesures dans le presse papier</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="946"/>
        <source>Exporter vers ....</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="951"/>
        <source>Oo.o Calc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="956"/>
        <source>Qtiplot</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="961"/>
        <source>SciDAVis</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="969"/>
        <source>changer d&apos;échelle ?</source>
        <translation>changer d&apos;échelle ?</translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1009"/>
        <source>&amp;Fichier</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1013"/>
        <source>E&amp;xporter vers ...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1030"/>
        <source>&amp;Aide</source>
        <translation></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1039"/>
        <source>&amp;Edition</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="1056"/>
        <source>&amp;Ouvrir une vidéo (Ctrl-O)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1064"/>
        <source>avanceimage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1069"/>
        <source>reculeimage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1074"/>
        <source>Quitter (Ctrl-Q)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="1082"/>
        <source>Enregistrer les données (Ctrl-S)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="1090"/>
        <source>À &amp;propos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1095"/>
        <source>Aide (F1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1103"/>
        <source>Exemples ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="1108"/>
        <source>Ouvrir un projet &amp;mecavidéo</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="1113"/>
        <source>&amp;Préférences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1118"/>
        <source>&amp;Copier dans le presse-papier (Ctrl-C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="1126"/>
        <source>Défaire (Ctrl-Z)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1134"/>
        <source>Refaire (Ctrl-Y)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1142"/>
        <source>OpenOffice.org &amp;Calc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1147"/>
        <source>Qti&amp;plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="1152"/>
        <source>Sci&amp;davis</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="174"/>
        <source>Pas de vidéos chargées</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="265"/>
        <source>Acquisition video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="367"/>
        <source>Acquisition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="637"/>
        <source>suivi
automatique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="648"/>
        <source>Changer d&apos;origine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="780"/>
        <source>Montrer 
les vecteurs
vitesses</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="789"/>
        <source>près de
la souris</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pymecavideo_mini.ui" line="800"/>
        <source>partout</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="pymecavideo_mini.ui" line="920"/>
        <source>Définir un autre référentiel : </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>self.app</name>
    <message>
        <location filename="cadreur.py" line="48"/>
        <source>Presser la touche ESC pour sortir</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="echelle.py" line="142"/>
        <source>Choisir le nombre de points puis « Démarrer l&apos;acquisition » </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="echelle.py" line="147"/>
        <source>Vous pouvez continuer votre acquisition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="preferences.py" line="48"/>
        <source>Proximite de la souris %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="preferences.py" line="49"/>
        <source>; derniere video %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="preferences.py" line="50"/>
        <source>; videoDir %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
